-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 03, 2020 at 11:00 AM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `demodb`
--

-- --------------------------------------------------------

--
-- Table structure for table `event_member_table`
--

CREATE TABLE `event_member_table` (
  `event_mem_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL,
  `event_participant` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `event_member_table`
--

INSERT INTO `event_member_table` (`event_mem_id`, `event_id`, `event_participant`) VALUES
(7, 2, '1'),
(8, 1, '1'),
(9, 3, '1'),
(12, 1, '1'),
(13, 1, '1'),
(14, 2, '1'),
(15, 2, '1');

-- --------------------------------------------------------

--
-- Table structure for table `event_table`
--

CREATE TABLE `event_table` (
  `event_id` int(11) NOT NULL,
  `event_name` varchar(22) NOT NULL,
  `event_content` varchar(50) NOT NULL,
  `event_date` date NOT NULL,
  `event_status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `event_table`
--

INSERT INTO `event_table` (`event_id`, `event_name`, `event_content`, `event_date`, `event_status`) VALUES
(1, 'asdf', 'adsfasdfasdf', '0000-00-00', 1),
(2, 'wrewerw', 'wrwerewrw', '1995-02-02', 1),
(3, 'sda', 'dasd', '2020-08-19', 0),
(4, 'asdsd', 'asdasdasdasdfrtertertertetert', '2020-08-05', 1);

-- --------------------------------------------------------

--
-- Table structure for table `register_table`
--

CREATE TABLE `register_table` (
  `reg_id` int(11) NOT NULL,
  `reg_type` int(11) NOT NULL,
  `reg_name` varchar(22) NOT NULL,
  `reg_email` varchar(22) NOT NULL,
  `reg_phone` int(10) NOT NULL,
  `reg_password` varchar(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register_table`
--

INSERT INTO `register_table` (`reg_id`, `reg_type`, `reg_name`, `reg_email`, `reg_phone`, `reg_password`) VALUES
(1, 1, 'admin', 'admin@gmail.com', 1234567890, '12345678'),
(2, 2, 'student', 'stu@gmail.com', 454534533, '11111111'),
(3, 2, 'jai', 'jai@gmail.com', 32423423, 'dddddddd'),
(4, 2, 'jaisre', 'jai342@gmail.com', 32423423, 'hhhhhh'),
(5, 2, 'ggggasdfsd', 'asdf@fas.co', 2342342, 'asdfdasf'),
(6, 2, 'ggggasdfsd', 'asdf@fas.co', 2342342, 'cccccccc'),
(7, 2, 'faasdfasdfas', 'asdf@dfa.co', 34234, 'asdf'),
(8, 2, 'fad', 'asf@dfsd.co', 423423, 'asdf'),
(9, 2, 'siva', 'siva@gmail.com', 1234567, 'siva');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `event_member_table`
--
ALTER TABLE `event_member_table`
  ADD PRIMARY KEY (`event_mem_id`);

--
-- Indexes for table `event_table`
--
ALTER TABLE `event_table`
  ADD PRIMARY KEY (`event_id`);

--
-- Indexes for table `register_table`
--
ALTER TABLE `register_table`
  ADD PRIMARY KEY (`reg_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `event_member_table`
--
ALTER TABLE `event_member_table`
  MODIFY `event_mem_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `event_table`
--
ALTER TABLE `event_table`
  MODIFY `event_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `register_table`
--
ALTER TABLE `register_table`
  MODIFY `reg_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
