<div class="container">  

  <h3>EVENTS</h3>
  
  <hr>
  <a href='<?php echo base_url()."login"; ?>'>Logout</a>  
  
  <div class="row">
  <?php  
  	//print_r( $this->session->all_userdata());
	$valid_user= $this->session->userdata('reg_email');
	//echo $name;
	  if($valid_user=='admin@gmail.com'){
	  
  ?> 
    <?php
echo $this->session->flashdata('success');
?>
    <?=form_open_multipart(base_url().'register/event_add',array('class'=>'form-horizontal mb-0','id'=>'registeradd'));?>					
        <div class="demo-table">
        <div class="form-head">Event add</div>            
            <div class="field-column">
                <label>Event name</label>
                <div>
                    <input type="text" class="demo-input-box"
                        name="event_name"
                        value="">
                </div>
            </div>
            
            <div class="field-column">
                <label>Content</label>
                <div><input type="password" class="demo-input-box"
                    name="event_content" value=""></div>
            </div>
           
            <div class="field-column">
                <label>date</label>
                <div>
                    <input type="date" class="demo-input-box"
                        name="event_date"
                        value="">
                </div>
            </div>			
			<div class="field-column">                
                <div>
                    <input type="submit"
                         value="save"
                        class="btnRegister">
                </div>
            </div>
        </div>
    <?=form_close();?>
	<?php
	}
  
   ?>
    <div class="clearfix visible-sm visible-xs">
      &nbsp;
    </div>
    <div class="col-lg-4 col-lg-pull-8 col-md-4 col-md-pull-8">
      <ul class="nav nav-pills" role="tablist">
        <li class="active">
          <a data-toggle="tab" href="#tab1" role="tab">Events</a>
        </li>
       
      </ul>
    </div>
  </div><!-- / row -->
  <hr>
  <div class="tab-content">
    <div class="tab-pane fade in active" id="tab1">
      <div class="row">
        <div class="col-md-6">
		<?php
		foreach($result as $event)
												{
													$event_name=htmlentities($event['event_name']);
													$event_id=htmlentities($event['event_id']);
													$event_status=htmlentities($event['event_status']);
													$event_date=htmlentities($event['event_date']);
													$event_content=htmlentities($event['event_content']);
													?>
          <div class="media">
            <a class="pull-left" href="#"><span class="dateEl"><em><?=$event_date;?></em></span></a>
            <div class="media-body">
              <h4 class="media-heading">
                <a href="#"><?=$event_name;?><?php  
				//print_r( $this->session->all_userdata());
				$valid_user= $this->session->userdata('reg_email');
				//echo $name;
				  if($valid_user=='admin@gmail.com'&& $event_status==1){				  
			  ?> <p id="demo">booked</p></a>
              <?php }?>
			  <?php  
				//print_r( $this->session->all_userdata());
				$valid_user= $this->session->userdata('reg_email');
				//echo $name;
				  if($valid_user!='admin@gmail.com' && $event_status!=1){				  
			  ?>
<button type="submit" class="btn_card btn mt-3 YB_event <?php if($valid_user=='admin@gmail.com'){echo "d-none"; }?> cursor " id="<?=$event_id;?>" onclick="enableTxt(this)"  data-toggle="modal" data-target=".raise_ticket_booking">Booking</button>													
				  <?php }?>
				  </h4>
              <div class="meta-data">
                <span class="longDate"></span><?=$event_date;?> <span class="timeEl">12:00pm - 02:00pm</span>
              </div>
              <p>
                <?=$event_content;?>
              </p>
            </div><!-- / media-body -->
          </div><!-- / media -->
		  
												<?php
												}?>
          
        </div><!-- / .col-md-6 -->
      </div><!-- / row -->
      <div class="text-center">
        <br>
        <a class="btn btn-default" href="#">SEE ALL EVENTS</a>
      </div>
    </div>
    <!--<div class="modal fade raise_ticket_booking" data-backdrop="static">
						<div class="modal-dialog modal-dialog-centered">
							<div class="modal-content">
								<div class="modal-header">
									<h6 class="modal-title font-weight-bold">booking Ticket</h6>
									<button type="button" class="close" data-dismiss="modal">&times;</button>
								</div>
								    
								<div class="modal-body">
									<p>Do You Really Want To booking This Ticket?</p>
									<div class="modal-footer p-2 border-0 text-right pb-0">
									
										<a href="<?=base_url()?>register/booking/<?=$event_id;?>"><button type="button" class="btn_card_solid" value="">yes</button> </a>
										<button type="button" class="btn_card_solid_b" data-dismiss="modal">No</button>
									</div>
								</div>
							</div>
						</div>
					</div>-->
  </div>
</div>

<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script>

//var hidden = false;
function enableTxt(elem) {
	//alert('sdf');	
    var id = $(elem).attr("id");
    //alert(id);
	posturl_20="<?php echo base_url() ?>register/booking";	
    $.post(posturl_20,{
        id: id,       
    },function(res){
        location.reload();
    });
	      
}
</script>