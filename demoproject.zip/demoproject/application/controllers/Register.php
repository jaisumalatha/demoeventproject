<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Register extends CI_Controller {
public function __construct()
{
    parent::__construct();

    $this->load->library('form_validation');    
    $this->load->helper('form');
    $this->load->helper('url');
    $this->load->model('event_model');
}
public function register_view()
	{
		$this->load->view('Register');
	}
 function dashboard()
	{
		$data['name'] = $this->session->userdata('reg_name');
		$data['result'] = $this->event_model->get_event_list();
		$data['result2'] = $this->event_model->get_register_list();
		//$data['result3'] = $this->event_model->get_event_mem_list();
		$this->load->view('dashboard',$data);
	}
    public function data()  
    {  
        if ($this->session->userdata('currently_logged_in'))   
        {  
            $this->load->view('dashboard');  
        } else {  
            redirect('login');  
        }  
    }  
  function register_add()
	{
			
			if($_POST)
			{
				$reg_name=$this->input->post('reg_name');
				$reg_password=$this->input->post('reg_password');
				$reg_email=$this->input->post('reg_email');
				$reg_phone=$this->input->post('reg_phone');
				$reg_type='2';
				$data1= array('reg_name'=>$reg_name,'reg_password'=>$reg_password,'reg_email'=>$reg_email,'reg_phone'=>$reg_phone,'reg_type'=>$reg_type);
					//$this->db->insert('register_table',$data1);
				$res = $this->db->insert('register_table',$data1);
				if($res==true)
				{
					$this->session->set_flashdata('success', "successfully add"); 
				}else{
					$this->session->set_flashdata('error', "ERROR_MESSAGE_HERE");
				}
			}
			redirect('login');			
	}
	function booking_add()
	{
		
			$event_id=$this->input->post('id');	
		
			$data = array('event_status' => 1);
				
			$where=array('event_id'=>$event_id);
			
			$res=$this->event_model->eventdata_update($where,$data);
				
			redirect('dashboard');			
	}
    public function login()  
    {  
        $this->load->helper('security');  
        $this->load->library('form_validation');  
  
        $this->form_validation->set_rules('reg_email', 'reg_email:', 'required|trim|xss_clean|callback_validation');  
        //$this->form_validation->set_rules('reg_type', 'reg_type:', 'required|trim|xss_clean|callback_validation');  
        $this->form_validation->set_rules('reg_password', 'reg_password:', 'required|trim');  
			//$SESS_USER_ID=$this->session->userdata('SESS_USER_ID');
			//$SESS_TYPE_ID=$this->session->userdata('reg_type');
			
		    //$data['SESS_TYPE_ID']=$SESS_TYPE_ID;
        if ($this->form_validation->run())   
        {  
            $data = array(  
                'reg_email' => $this->input->post('reg_email'),				
				//'reg_password' => $this->input->post('reg_password'),				
                //'currently_logged_in' => 2  
                );    
                    $this->session->set_userdata($data);  
                redirect('dashboard');  
        }   
        else {  
            $this->load->view('login');  
        }  
    }  
  
    
  
    public function validation()  
    {  
        $this->load->model('event_model');  
  
        if ($this->event_model->log_in_correctly())  
        {  
  
            return true;  
        } else {  
            $this->form_validation->set_message('validation', 'Incorrect username/password.');  
            return false;  
        }  
    }  
  
    public function logout()  
    {  
        $this->session->sess_destroy();  
        redirect('login');  
    }  
  
}  
?> 
	