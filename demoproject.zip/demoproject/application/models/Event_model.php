<?php
if(!defined('BASEPATH')){exit('No direct script access allowed');}
class Event_model extends CI_Model
{
	//Function-1 : get event list
	function get_event_list()
	{			
		$this->db->select("*");
		$this->db->from('event_table');
		$query=$this->db->get();
		return $query->result_array();
	}
	function get_register_list()
	{			
		$this->db->select("*");
		$this->db->from('register_table');
		$query=$this->db->get();
		return $query->row_array();
	}
	
	function eventdata_update($where,$data)
	{
		
			$this->db->where($where);
			
			$this->db->update('event_table',$data);
			
			return $this->db->affected_rows();
		
	}
	public function log_in_correctly() {  
		$this->db->select("*");
        $this->db->where('reg_email', $this->input->post('reg_email')); 
		//$this->db->where('reg_type', $this->input->post('reg_type')); 		
        $this->db->where('reg_password', $this->input->post('reg_password'));  
        $query = $this->db->get('register_table');  
  
        if ($query->num_rows() == 1)  
        {  
            return true;  
        } else {  
            return false;  
        }  
  
    }  

}
?>